# -*- coding: utf-8 -*-
"""
/***************************************************************************
 OtroPlugin
                                 A QGIS plugin
 Este es otro plugin
                             -------------------
        begin                : 2015-08-09
        copyright            : (C) 2015 by Ronico Inc
        email                : imworkingnow@msn.com
        git sha              : $Format:%H$
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
 This script initializes the plugin, making it known to QGIS.
"""


# noinspection PyPep8Naming
def classFactory(iface):  # pylint: disable=invalid-name
    """Load OtroPlugin class from file OtroPlugin.

    :param iface: A QGIS interface instance.
    :type iface: QgsInterface
    """
    #
    from .otroplugin import OtroPlugin
    return OtroPlugin(iface)
