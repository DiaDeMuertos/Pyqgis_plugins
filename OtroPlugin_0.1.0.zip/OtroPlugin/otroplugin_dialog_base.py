# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'otroplugin_dialog_base.ui'
#
# Created: Sun Aug 09 20:19:33 2015
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_OtroPluginDialogBase(object):
    def setupUi(self, OtroPluginDialogBase):
        OtroPluginDialogBase.setObjectName(_fromUtf8("OtroPluginDialogBase"))
        OtroPluginDialogBase.resize(395, 300)
        self.button_box = QtGui.QDialogButtonBox(OtroPluginDialogBase)
        self.button_box.setGeometry(QtCore.QRect(230, 268, 156, 23))
        self.button_box.setOrientation(QtCore.Qt.Horizontal)
        self.button_box.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.button_box.setObjectName(_fromUtf8("button_box"))
        self.label = QtGui.QLabel(OtroPluginDialogBase)
        self.label.setGeometry(QtCore.QRect(90, 120, 197, 23))
        font = QtGui.QFont()
        font.setPointSize(14)
        self.label.setFont(font)
        self.label.setObjectName(_fromUtf8("label"))

        self.retranslateUi(OtroPluginDialogBase)
        QtCore.QObject.connect(self.button_box, QtCore.SIGNAL(_fromUtf8("accepted()")), OtroPluginDialogBase.accept)
        QtCore.QObject.connect(self.button_box, QtCore.SIGNAL(_fromUtf8("rejected()")), OtroPluginDialogBase.reject)
        QtCore.QMetaObject.connectSlotsByName(OtroPluginDialogBase)

    def retranslateUi(self, OtroPluginDialogBase):
        OtroPluginDialogBase.setWindowTitle(_translate("OtroPluginDialogBase", "Otro Plugin", None))
        self.label.setText(_translate("OtroPluginDialogBase", "Hola este es otro Plugin", None))

